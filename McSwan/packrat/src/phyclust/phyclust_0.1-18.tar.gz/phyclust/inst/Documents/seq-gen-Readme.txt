This package is the generic source-code version. This can be compiled
and run on most UNIX/Linux/Mac OS X systems. It can also be compiled 
for Windows. For Mac OS X a pre-compiled version is available from
the website:

http://evolve.zoo.ox.ac.uk/software/Seq-Gen/

There is a manual in HTML format in the doc/ directory of this package.

On most UNIX systems, to compile, type:

cd source
make

A binary called 'seq-gen' will be created in the same directory as this
README file.

Any questions about Seq-Gen should be sent to:

	Andrew Rambaut <andrew.rambaut@zoo.ox.ac.uk>