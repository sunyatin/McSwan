#.Color <- c("#00EEEEFF", "#A0EEEEFF", "#AAC6EEFF", "#EEC6BBFF",
#            "#EE66EEFF", "#DEAA00FF", "#EECF5EFF", "grey65", "grey80",
#            "#60FF00FF", "#C9FF00FF")
#.Color.org <- c("#00EEEEFF", "#AAC6EEFF", "#EE66EEFF", "#EEC6BBFF", "grey65",
#                "#60FF00FF", "#A0EEEEFF", "#EECF5EFF", "grey80", "#DEAA00FF",
#                "#C9FF00FF")
#.Color <- c("#0080ff", "#ff00ff", "darkgreen", "#ff0000", "orange", "#00ff00",
#            "brown", "#00eeee")
.Color <- c("#0080ff", "#ff00ff", "darkgreen", "#ff0000", "orange",
            "#00ff00", "brown", "#00eeee", "#BB66BB", "#DEAA00",
            "#EECF5E", "#B0FFFF", "#AAC6EE", "#EEC6BB", "grey65")
# pie(rep(1, length(.Color)), col = .Color)

